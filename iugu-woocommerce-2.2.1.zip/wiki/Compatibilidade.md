O **WooCommerce iugu** é compatível com:

* [WooCommerce 3.0+](https://wordpress.org/plugins/woocommerce/)
* [WooCommerce Subscriptions](http://www.woothemes.com/products/woocommerce-subscriptions/): para pagamentos recorrentes/assinaturas.
* [WooCommerce Pre-orders](http://www.woothemes.com/products/woocommerce-pre-orders/): para pré-venda de produtos.
* [WooCommerce Extra Checkout Fields for Brazil](https://br.wordpress.org/plugins/woocommerce-extra-checkout-fields-for-brazil/): permite enviar dados do cliente como **CPF** ou **CNPJ**, além dos campos **número** e **bairro** do endereço.
