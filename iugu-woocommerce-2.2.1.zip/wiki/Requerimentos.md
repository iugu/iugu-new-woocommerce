* [Wordpress v3.9 ou superior](https://wordpress.org).
* [WooCommerce v3.0 ou superior](https://br.wordpress.org/plugins/woocommerce/).
* [WooCommerce Extra Checkout Fields for Brazil](https://br.wordpress.org/plugins/woocommerce-extra-checkout-fields-for-brazil/).
* Conta ativa na [iugu](https://iugu.com/) com boleto bancário e/ou cartão de crédito habilitados como métodos de pagamento. Entenda [*O que é necessário para começar a usar iugu?*](https://support.iugu.com/hc/pt-br/articles/201531709).

Veja também como [instalar e ativar o **WooCommerce iugu**](https://github.com/iugu/iugu-woocommerce/wiki/Configura%C3%A7%C3%A3o).
