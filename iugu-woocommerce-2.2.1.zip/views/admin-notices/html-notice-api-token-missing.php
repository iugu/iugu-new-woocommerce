<?php
/**
 * Admin View: Notice - API Token missing.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="error">
	<p><strong><?php _e( 'iugu disabled', 'iugu-woocommerce' ); ?></strong>: <?php _e( 'You should inform your account ID.', 'iugu-woocommerce' ); ?>
	</p>
</div>
